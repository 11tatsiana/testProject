/*************************************************************************
* MediaCoder extension - Archos AV Series
* Distributed under GPL license
* Copyright (c) 2005-06 Stanley Huang <stanleyhuangyc@yahoo.com.cn
* All rights reserved.
*************************************************************************/

function SetModel(model)
{
	SendCommand("stop_play");
	// switch picture
	if (model == "0") {
		// resize window
		window.innerWidth = 910;
		window.innerHeight = 400;
		devimg.src = "av700.png";
		lcd.style.left = 338;
		lcd.style.top = 84;
	} else {
		devimg.src = "av500.png";
		window.innerWidth = 910;
		window.innerHeight = 460;
		lcd.style.left = 276;
		lcd.style.top = 129;
	}
	ApplyParams();
}

function ApplyParams()
{
	var doc = NewXML("MediaCoderPref");
	if (!doc) {
		alert("Error creating config XML");
		return;
	}
	
	var model = document.getElementById("model").value;
	var format = document.getElementById("format").value;
	
	AddPrefNode(doc, "overall.video.format", format);
	AddPrefNode(doc, "overall.video.bitrate", document.getElementById("vb").value);
	AddPrefNode(doc, "audioenc.lame.quality", document.getElementById("aq").value);
	AddPrefNode(doc, "videofilter.frame.fps", document.getElementById("fps").value);
	
	if (model == 0) {
		AddPrefNode(doc, "videofilter.scale.width", 480);
		AddPrefNode(doc, "videofilter.scale.height", 234);
	} else {
		AddPrefNode(doc, "videofilter.scale.width", 480);
		AddPrefNode(doc, "videofilter.scale.height", 272);
	}
	AddPrefNode(doc, "videofilter.crop.mode", document.getElementById("crop").value);
	
	// post settings to MediaCoder
	PostPrefXML(doc);
}

function Unload()
{
	// stop playback
	SendCommand("stop_play");
}
